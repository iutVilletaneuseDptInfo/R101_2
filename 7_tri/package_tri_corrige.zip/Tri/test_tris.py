import Tri.tris as tri

def test_tri_selection():
    tab = [8, 5, 6, 2, 3, 1, 4, 9, 7]
    tri.tri_selection(tab)
    assert tab == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    
    tab = [7, 7, 2, 3, 8, -2, 0, 0, -3]
    tri.tri_selection(tab)
    assert tab == [-3, -2, 0, 0, 2, 3, 7, 7, 8]

    tab = []
    tri.tri_selection(tab)
    assert tab == []
    
    tab = [1]
    tri.tri_selection(tab)
    assert tab == [1]
    
    tab = [-5, -1, 9]
    tri.tri_selection(tab)
    assert tab == [-5, -1, 9]

    print("Test de la fonction tri_selection : ok")


def test_tri_insertion():
    tab = [8, 5, 6, 2, 3, 1, 4, 9, 7]
    tri.tri_insertion(tab)
    assert tab == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    
    tab = [7, 7, 2, 3, 8, -2, 0, 0, -3]
    tri.tri_insertion(tab)
    assert tab == [-3, -2, 0, 0, 2, 3, 7, 7, 8]

    tab = []
    tri.tri_insertion(tab)
    assert tab == []
    
    tab = [1]
    tri.tri_insertion(tab)
    assert tab == [1]
    
    tab = [-5, -1, 9]
    tri.tri_insertion(tab)
    assert tab == [-5, -1, 9]

    print("Test de la fonction tri_insertion : ok")


def test_tri_bulle():
    tab = [8, 5, 6, 2, 3, 1, 4, 9, 7]
    tri.tri_bulle(tab)
    assert tab == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    
    tab = [7, 7, 2, 3, 8, -2, 0, 0, -3]
    tri.tri_bulle(tab)
    assert tab == [-3, -2, 0, 0, 2, 3, 7, 7, 8]

    tab = []
    tri.tri_bulle(tab)
    assert tab == []
    
    tab = [1]
    tri.tri_bulle(tab)
    assert tab == [1]
    
    tab = [-5, -1, 9]
    tri.tri_bulle(tab)
    assert tab == [-5, -1, 9]

    print("Test de la fonction tri_bulle : ok")


def test_tri_comptage():
    tab = [8, 5, 6, 2, 3, 1, 4, 9, 7]
    tri.tri_comptage(tab)
    assert tab == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    
    tab = [7, 7, 2, 3, 8, -2, 0, 0, -3]
    tri.tri_comptage(tab)
    assert tab == [-3, -2, 0, 0, 2, 3, 7, 7, 8]

    tab = []
    tri.tri_comptage(tab)
    assert tab == []
    
    tab = [1]
    tri.tri_comptage(tab)
    assert tab == [1]
    
    tab = [-5, -1, 9]
    tri.tri_comptage(tab)
    assert tab == [-5, -1, 9]

    print("Test de la fonction tri_comptage : ok")