import Tri.utils as utils

import math


def test_swap_tab():
    tab = [8, 5, 6, 2, 3, 1, 4, 9, 7]
    utils.swap_tab(tab, 0, 1)
    assert tab == [5, 8, 6, 2, 3, 1, 4, 9, 7]
    utils.swap_tab(tab, 4, 6)
    assert tab == [5, 8, 6, 2, 4, 1, 3, 9, 7]
    utils.swap_tab(tab, 5, 5)
    assert tab == [5, 8, 6, 2, 4, 1, 3, 9, 7]
    utils.swap_tab(tab, 7, 8)
    assert tab == [5, 8, 6, 2, 4, 1, 3, 7, 9]
    print("Test de la fonction swap_tab : ok")


def test_tab_init():
    assert utils.tab_init(3, 0) == [0, 0, 0]
    assert utils.tab_init(0, 3) == []
    assert utils.tab_init(5, 10) == [10, 10, 10, 10, 10]
    assert utils.tab_init(10, 5) == [5, 5, 5, 5, 5, 5, 5, 5, 5, 5]
    assert utils.tab_init(3, "abc") == ["abc", "abc", "abc"]
    print("Test de la fonction tab_init : ok")


def test_moyenne():
    assert math.isclose(utils.moyenne([0, 0, 0]), 0)
    assert math.isclose(utils.moyenne([14, 14, 14, 14]), 14)
    assert math.isclose(utils.moyenne([0.1, 0.2]), 0.15)
    assert math.isclose(utils.moyenne([1, 2, 3, 4, 5, 6]), 21/6)
    print("Test de la fonction moyenne : ok")