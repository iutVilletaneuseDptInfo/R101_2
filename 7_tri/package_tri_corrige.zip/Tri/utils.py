from random import randint


def swap_tab(tab, i, j):
    """
        Échange le contenu des cases i et j dans le tableau tab
    """
    buf = tab[i]
    tab[i] = tab[j]
    tab[j] = buf


def tab_init(longueur, val):
    """
        Retourne un tableau contenant longueur cases initialisées à val.
    """
    tab = []
    i = 0
    while i < longueur:
        tab.append(val)
        i += 1
    return tab

def tab_alea(longueur):
    """
        Retourne un tableau de longueur cases initialisées aléatoirement avec des entiers
        compris entre 0 et longueur / 2 (arrondi à l'entier inférieur).
    """
    tab = []
    i = 0
    while i < longueur:
        tab.append(randint(0, longueur // 2))
        i += 1
    return tab


def moyenne(tab):
    """
        Retourne la moyenne des éléments du tableau tab.
    """
    somme = 0
    i = 0
    while i < len(tab):
        somme += tab[i]
        i += 1
    return somme / len(tab)